'use client'

import { useState } from 'react'

export default function Dashboard() {
  const [prompt, setPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null)

  const handleGenerate = async () => {
    setIsGenerating(true)
    
    try {
      const response = await fetch('/api/generate-video', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt }),
      })
      
      const data = await response.json()
      if (data.success) {
        setGeneratedVideo(data.videoUrl)
      }
    } catch (error) {
      console.error('Error generating video:', error)
    }
    
    setIsGenerating(false)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Generar nuevo video</h2>
          
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe el video que quieres generar..."
            className="w-full h-32 p-3 border border-gray-300 rounded-md resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isGenerating ? 'Generando...' : 'Generar Video'}
          </button>
        </div>

        {generatedVideo && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Video Generado</h2>
            <video 
              src={generatedVideo} 
              controls 
              className="w-full rounded-md"
            />
            <div className="mt-4">
              <button className="bg-green-600 text-white px-4 py-2 rounded-md mr-2">
                Descargar
              </button>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md">
                Compartir
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}