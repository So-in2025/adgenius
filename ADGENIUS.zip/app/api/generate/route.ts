import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  // Redirigir a generate-video para mantener compatibilidad
  return NextResponse.json(
    { error: 'Use /api/generate-video instead' },
    { status: 301 }
  );
}