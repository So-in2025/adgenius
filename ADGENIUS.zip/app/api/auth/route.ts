import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  // placeholder para auth
  return NextResponse.json({ message: 'Auth endpoint' });
}